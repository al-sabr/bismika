const element = document.createElement('p');
element.innerText = "Hello from automated embedding examples index.js!";

document.body.append(element);
